#!/bin/sh
echo "Content-Type: text/html"
echo
echo "<H1>CGI Environment</H1>"
echo "<PRE>"
set 2>&1
echo "</PRE>"

